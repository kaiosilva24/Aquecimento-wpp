import express from 'express';
import { runQuery, allQuery, getQuery } from '../database/database.js';
import whatsappManager from '../services/whatsappManager.js';

const router = express.Router();

// Get all accounts
router.get('/', async (req, res) => {
    try {
        const accounts = await allQuery('SELECT * FROM accounts ORDER BY created_at DESC');
        res.json(accounts);
    } catch (error) {
        console.error('Error getting accounts:', error);
        res.status(500).json({ error: 'Failed to get accounts' });
    }
});

// Add new account
router.post('/', async (req, res) => {
    try {
        const { name, proxyId, networkMode } = req.body;

        if (!name) {
            return res.status(400).json({ error: 'Account name is required' });
        }

        const result = await runQuery(
            'INSERT INTO accounts (name, status, proxy_id, network_mode) VALUES (?, ?, ?, ?)',
            [name, 'disconnected', proxyId || null, networkMode || 'local']
        );

        const accountId = result.id;

        // Create WhatsApp client
        await whatsappManager.createClient(accountId, name);

        res.json({
            id: accountId,
            name,
            status: 'disconnected',
            network_mode: networkMode || 'local',
            message: 'Account created. Scan QR code to connect.'
        });
    } catch (error) {
        console.error('Error creating account:', error);
        res.status(500).json({ error: 'Failed to create account' });
    }
});

// Get account status
router.get('/:id/status', async (req, res) => {
    try {
        const { id } = req.params;
        const account = await getQuery('SELECT * FROM accounts WHERE id = ?', [id]);

        if (!account) {
            return res.status(404).json({ error: 'Account not found' });
        }

        const isConnected = whatsappManager.isConnected(parseInt(id));

        res.json({
            ...account,
            is_connected: isConnected
        });
    } catch (error) {
        console.error('Error getting account status:', error);
        res.status(500).json({ error: 'Failed to get account status' });
    }
});

// Get QR code for account
router.get('/:id/qr', async (req, res) => {
    try {
        const { id } = req.params;
        const qrCode = whatsappManager.getQRCode(parseInt(id));

        if (!qrCode) {
            return res.status(404).json({ error: 'QR code not available. Account may already be connected.' });
        }

        res.json({ qr_code: qrCode });
    } catch (error) {
        console.error('Error getting QR code:', error);
        res.status(500).json({ error: 'Failed to get QR code' });
    }
});

// Delete account
router.delete('/:id', async (req, res) => {
    try {
        const { id } = req.params;

        // Disconnect client first
        await whatsappManager.disconnectClient(parseInt(id));

        // Delete from database
        await runQuery('DELETE FROM accounts WHERE id = ?', [id]);

        res.json({ message: 'Account deleted successfully' });
    } catch (error) {
        console.error('Error deleting account:', error);
        res.status(500).json({ error: 'Failed to delete account' });
    }
});

// Reconnect account
router.post('/:id/reconnect', async (req, res) => {
    try {
        const { id } = req.params;
        const account = await getQuery('SELECT * FROM accounts WHERE id = ?', [id]);

        if (!account) {
            return res.status(404).json({ error: 'Account not found' });
        }

        await whatsappManager.createClient(parseInt(id), account.name);

        res.json({ message: 'Reconnection initiated. Scan QR code if needed.' });
    } catch (error) {
        console.error('Error reconnecting account:', error);
        res.status(500).json({ error: 'Failed to reconnect account' });
    }
});

// Update account network mode
router.put('/:id/network-mode', async (req, res) => {
    try {
        const { id } = req.params;
        const { networkMode } = req.body;

        if (!networkMode || !['local', 'proxy'].includes(networkMode)) {
            return res.status(400).json({ error: 'Invalid network mode. Must be "local" or "proxy".' });
        }

        const account = await getQuery('SELECT * FROM accounts WHERE id = ?', [id]);
        if (!account) {
            return res.status(404).json({ error: 'Account not found' });
        }

        await runQuery(
            'UPDATE accounts SET network_mode = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?',
            [networkMode, id]
        );

        res.json({
            message: 'Network mode updated successfully',
            network_mode: networkMode
        });
    } catch (error) {
        console.error('Error updating network mode:', error);
        res.status(500).json({ error: 'Failed to update network mode' });
    }
});

export default router;
