import fetch from 'node-fetch';
import { HttpsProxyAgent } from 'https-proxy-agent';
import { SocksProxyAgent } from 'socks-proxy-agent';
import proxyService from './proxyService.js';
import { getQuery } from '../database/database.js';

const networkService = {
    // Check current external IP and Provider
    async getNetworkStatus(accountId) {
        try {
            let proxyConfig = null;

            // If accountId provided, check assigned proxy
            if (accountId) {
                const account = await getQuery('SELECT proxy_id FROM accounts WHERE id = ?', [accountId]);
                if (account && account.proxy_id) {
                    proxyConfig = await proxyService.getById(account.proxy_id);
                }
            } else {
                // Legacy/Global check - check if any global default exists (future proofing) or just return direct
            }

            let agent = null;

            if (proxyConfig && proxyConfig.active && proxyConfig.host) {
                const protocol = proxyConfig.protocol || 'http';
                const auth = (proxyConfig.auth_enabled && proxyConfig.username && proxyConfig.password)
                    ? `${proxyConfig.username}:${proxyConfig.password}@`
                    : '';

                const proxyUrl = `${protocol}://${auth}${proxyConfig.host}:${proxyConfig.port}`;

                if (protocol.startsWith('socks')) {
                    agent = new SocksProxyAgent(proxyUrl);
                } else {
                    agent = new HttpsProxyAgent(proxyUrl);
                }
            }

            // Using ip-api.com (free, non-commercial use, limited rate)
            // Alternative: ipapi.co or similar
            const response = await fetch('http://ip-api.com/json/', { agent });

            if (!response.ok) {
                throw new Error(`Network check failed: ${response.statusText}`);
            }

            const data = await response.json();

            if (data.status === 'fail') {
                return {
                    ip: 'Unavailable',
                    provider: 'Unknown',
                    country: 'Unknown',
                    error: data.message
                };
            }

            return {
                ip: data.query,
                provider: data.isp || data.org,
                country: data.countryCode,
                proxy: proxyConfig ? proxyConfig.name : 'Direct'
            };

        } catch (error) {
            console.error('Error checking network status:', error);
            return {
                ip: 'Error',
                provider: 'Connection Failed',
                error: error.message
            };
        }
    }
};

export default networkService;
